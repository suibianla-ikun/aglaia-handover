# 给 Windows 智能体的完整执行提示词

你在我的 Windows 电脑上工作。请现在开始连续实施，把这份 Aglaia 交接包中的全部本地功能移植到 Windows 客户端，最终构建并验收真正可安装的 Windows `.exe` 安装包。不要仅写计划、解释改法，或停在源码修改、测试、便携 ZIP。遇到可以自行排查的问题要继续解决；只有确实需要我提供材料、凭据或系统授权时，才说明具体阻塞。

## 交接材料与基线

先找到随本提示词提供的交接目录，读取 `README.md` 全文、`files.md`、`changes.json`、`test-results.json`、`verification.json`、`runtime-metadata.json` 和完整 `aglaia-local-changes.patch`；汉化细节使用 `zh-translations.tsv` / `zh-translations.json`。

上游是 `https://github.com/yb85/aglaia`，本包对照基线为 `38429ba2b4b7476abc13c2db6009f102013c7ae9`。本包是净改动补丁，不是完整源码、不含模型，也不是现成安装器。Mac 的 272 项 GUI/汉化检查通过，不代表 Windows 的测试、OCR 或安装已经通过。

检查本机现有 Aglaia 源码、Git 状态、Python/uv/Qt、操作系统架构、构建工具和已有 OCR 后端。找不到源码时再获取上游并核验准确基线，不默认拿最新版本强行应用旧补丁。基线相同且工作区干净时，先运行 `git apply --check`；版本不同或工作区有变化时按模块对照移植，保留既有代码，禁止重置、覆盖或清除用户改动。

## 必须移植的功能

完整功能和边界以 README 为准，不只搬下面的标题：

1. 简体中文 Qt 资源及流程、步骤、处理器、参数名称/说明/枚举的动态汉化。只改显示层，保留配置键与算法标识；打包后也可选中文。
2. iPhone HEIC/HEIF 真正解码和 EXIF 方向纠正，不只是放开扩展名。
3. 新建项目与已打开项目都支持整个目录选择、递归展开和目录拖入。
4. 导入队列、相同图片路径、相同 PDF 路径/页号的去重及提示；如实说明路径去重不等于内容去重。
5. 200 DPI 默认、100-600 图片输入范围、内置输出 200 DPI、不无谓放大已有大图和上采样像素预算。保留用户已有 YAML。
6. 防止危险文字凸包斜切正文的矩形回退，保留手动画边界。
7. OCR 默认简体中文和英文、当前页/页段与模型加载状态、完成/失败提示、图像处理的当前页面和步骤显示。
8. 失败终态、有限重试、双页分支重试隔离、单页手动恢复、软内存回收和新进程重试。
9. 底部状态栏主状态占主要空间，短日志放最右且可打开完整日志；检查高 DPI 缩放和长中文名称。
10. 普通 Markdown 的明显残缺防护；严格的“仅保留文本”导出、页索引和用户确认后的关闭后复核清理。两套检查不能混为一谈。
11. 从空流程创建、增删排序、命名保存/复用、草稿切换保留及“最终图像合成”说明。
12. 模型清单、冻结应用服务入口、HTML 列表双重编号修复及辅助比较工具。Mac 专用补丁不能假装是 Windows OCR 后端。
13. 完全移除打赏功能：启动页、侧栏、旧状态栏、设置开关、关于页支持作者链接、Ko-Fi 跳转、组件/注册接口、默认配置/helper、专用色、旧翻译。不是仅默认隐藏。
14. 关于页不展示版权/许可证段落，也不把作者版权改成我自己的。实际 `LICENSE`、源码头、项目许可证元数据、Required Notice 和第三方必要声明须保留，并随安装包附带为文件；无需增加日常界面展示。

旧 `disable_tip_buttons` 数据库记录可以继续保留但不再使用，不为清理它而重置个人配置。不要删除通用图标库中别的资源、插件系统、设置、进度、错误提示或正常导航。

## Windows 适配与数据保护

复用现有 Qt、Pillow/pillow-heif、SQLite、进程机制和 Windows 打包代码，不重写客户端、OCR 后台、存储或安装框架。

- Apple Vision、Apple Document、MLX、Metal、Mac bundle、互通相机与 Mac 权限不是 Windows 能力。Windows 默认 OCR 必须是本机真实可用且已实测的引擎；不可用引擎禁用或明确提示。
- 先判断现有 Windows OCR 支持。项目的 Windows CI 没有证明本地 Surya/GLM 可以运行；不依据旧 llama.cpp 注释、导入成功或已安装 Python 包就宣称可用。使用当前代码、实际后端及其官方支持范围排查，复用已有引擎适配。
- 不将书稿自动上传云端。需要云 OCR、API 密钥、付费订阅或额外模型下载时，先明确用途、去向、大小/费用并取得我针对该项的同意。没有条件实测时报告 OCR 阻塞，不能用空结果、模拟结果或默认云端掩盖。
- 不迁移 Mac `.app`、原 `.venv`、`.dylib`、模型缓存、个人配置数据库、API 密钥、`.env`、照片/PDF/书稿或 `.agl`。
- 只在临时测试目录测试删除、导入和归档。真实项目清理必须得到具体项目确认，且进程/句柄已关闭、文本输出和节点指纹复核通过。不删源照片/PDF、共享模型和用户策略。
- 不修改投资工作台、知识库、书籍蒸馏、IBKR/TWS、代理、服务器或交易系统。
- 不自动发布 GitHub Release、推送仓库或公开分发安装器。上游有许可限制，README 还把移除打赏后重打包描述为竞争行为；本任务只面向我的个人安装，不表示获得公开再分发许可。若我另要求面向他人分发，须先核实授权，不能删声明规避。

## 测试要求

先按改动模块做实际回归测试，再运行适合 Windows 的完整测试和 `localization_tests`。真实平台差异要适配并解释；不可删测试、放宽有效断言、伪造输出或把已有测试文件当作测试成功。记录命令、退出码、失败原因、修复与仍未验证范围。

重点检查 `tests/gui/test_no_donation_ui.py`；验证旧个人设置不会恢复打赏。另检查译文占位符、编译 `.qm`、目录/HEIC、重复 PDF、200 DPI、误裁、当前页/步骤、失败后解锁、手动修正、长文本状态栏、自定义流程和文本归档。

先使用合成/临时数据做危险删除路径验收。使用我明确提供的非敏感多页样本做“导入 -> 图像处理 -> OCR -> 全页文本导出”闭环，核对页序、双页分支、内容和完整性；没有样本时明确请求，不读电脑上不相关的私人材料。

## 必须构建安装器

先阅读当前 `Aglaia.spec`、`packaging/aglaia.iss`、`.github/workflows/release.yml` 的 `build-windows`。优先直接复用这些实现，只补实际缺失的资源/依赖和 Windows 适配。

以下是已有流程的参考，不是免核验命令：

```powershell
uv sync --locked --extra gui --extra voice --extra dev --extra package --extra cloud
uv run --no-sync pytest -q
uv run --no-sync pytest localization_tests -q
$env:AGLAIA_VERSION = "0.1.0rc7-zh.20261011"
uv run --no-sync pyinstaller Aglaia.spec --clean --noconfirm
& "${env:ProgramFiles(x86)}\Inno Setup 6\ISCC.exe" packaging\aglaia.iss
Get-FileHash "dist\Aglaia-windows-x64-setup.exe" -Algorithm SHA256
```

据实际源码和环境调整路径/版本/已选后端，每一步检查 `$LASTEXITCODE`，失败就停止该流水段并修复。`cloud` extra 是项目现有 Windows CI 的构建依赖选择，不授权上传书稿或调用云 API。不要在 Windows 安装 Mac/CUDA extras 来凑齐 import。

必须达到以下终点：

- 使用 PyInstaller onedir 输出完整 `dist\Aglaia\Aglaia.exe` 及依赖，不能仅交一个缺 DLL 的 exe。
- 使用现有 Inno Setup 输出真正的 `dist\Aglaia-windows-x64-setup.exe`。若机器不是 x64，先查现有支持和实际构建能力，不能把别的架构标为 x64。
- PyInstaller 与 Inno Setup 使用同一非空版本；中文版显示名、开始菜单/桌面快捷方式和 `.agl` 关联与实际安装路径一致。不要复制 Mac bundle ID；不要无故改现有 AppId 造成升级/卸载混乱。
- 验证 Inno Setup 简体中文语言文件后配置中文安装界面，不能编造不存在的 `.isl` 路径。
- 核验 Qt 平台插件、`.qm`、图标、YAML、SQLite schema、HEIC DLL 与实际 OCR 后端及其附属库已打入包。`LICENSE`/Required Notice 及必要第三方声明以文件进入安装目录；现有 spec 没有明确收集主 `LICENSE`，应补资源或 Inno `[Files]`，不要假设已经附带。
- 不把模型缓存、凭据、个人配置和书稿打进包。模型若需要另行安装/下载，软件需正确显示状态和授权边界，不把首次安装不含权重说成开箱 OCR 已就绪。
- 没有签名证书时可交付真实的未签名个人安装包，但必须标注未签名。不得假签、购买证书、禁用 Defender/SmartScreen 或自动绕过系统检查。
- 在 Windows 安装该产物，直接从快捷方式启动，验证翻译和关键功能，并重复多页样本闭环。核对 `.agl` 关联、重启、个人设置保存和升级保留数据。卸载检查只用本轮测试安装，不卸载用户既有软件或删除用户资料。

便携 ZIP 可以附带，但不能替代安装器；不得把交接 ZIP 改扩展名冒充安装包。

## 最终交付

给我实际文件路径：`.exe` 安装器、可选便携 ZIP、SHA-256 校验文件、构建/测试日志与一份简洁的完成报告。报告写清版本、架构、签名状态、OCR 后端、模型准备情况、Windows 实际通过的测试和安装验收、仍未完成项。

只有产物真实存在、哈希可核验、安装版实际测试通过，才能称“安装包已完成且已验收”。若只构建成功但 OCR/安装未验证，分开说明，不报全完成；把确切阻塞交给我，同时保留已完成的源码与真实产物。
