# 全部改动文件

基线：`38429ba2b4b7476abc13c2db6009f102013c7ae9`。78 个文件：57 个修改，21 个新增，含 20 个测试文件。

所有路径相对于 Aglaia 仓库根目录；新文件未跟踪状态也已包含在补丁中。完整 SHA-256 见 changes.json。

| 文件 | 状态 | 用途 |
| --- | --- | --- |
| `Aglaia.spec` | 修改 | 打包翻译资源、Mac 中文 bundle、冻结 MLX 服务依赖 |
| `README.md` | 修改 | 删除文档打赏邀请，保留上游许可说明 |
| `aglaia/__main__.py` | 修改 | 冻结应用内部 MLX-VLM 服务入口 |
| `aglaia/app.py` | 修改 | 默认导入 DPI、项目关闭后的文本归档清理 |
| `aglaia/app_data/db.py` | 修改 | OCR 默认简体中文和英文；移除打赏配置与读取函数 |
| `aglaia/app_data/downloads.py` | 修改 | Surya MLX 下载大小和必需权重清单 |
| `aglaia/assets/SKILL.md` | 修改 | Aglaia 操作说明的 DPI/像素预算补充 |
| `aglaia/config/pipelines/book_curved_x2.yaml` | 修改 | 内置流程输出DPI 300/300改为200/200 |
| `aglaia/config/pipelines/book_flat_x1.yaml` | 修改 | 内置流程输出DPI 300/300改为200/200 |
| `aglaia/config/pipelines/book_flat_x2.yaml` | 修改 | 内置流程输出DPI 300/300改为200/200 |
| `aglaia/config/pipelines/sheet_flat_x1.yaml` | 修改 | 内置流程输出DPI 300/300改为200/200 |
| `aglaia/gui/AboutDialog.py` | 修改 | 移除打赏链接及界面版权/许可证展示；源码声明保留 |
| `aglaia/gui/MainWindow.py` | 修改 | 去重提示、阶段进度、失败恢复、OCR提醒、导出守卫、文本归档；移除打赏注册和跳转 |
| `aglaia/gui/ModePicker.py` | 修改 | 模板汉化、固定新建入口、空流程、草稿保留 |
| `aglaia/gui/PipelineEditorWidget.py` | 修改 | 元数据汉化、自定义命名保存、枚举原值、最终合成说明 |
| `aglaia/gui/PipelineStepsOutline.py` | 修改 | 步骤和参数摘要汉化 |
| `aglaia/gui/ScanItemWidget.py` | 修改 | 失败页警示/手动恢复入口 |
| `aglaia/gui/SettingsTab.py` | 修改 | 双语言默认回退；删除打赏开关及其保存逻辑 |
| `aglaia/gui/StartupWindow.py` | 修改 | 新建项目目录导入、HEIC筛选、200 DPI及范围；删除打赏入口及专用发光样式 |
| `aglaia/gui/StatusBarWidget.py` | 修改 | 详细进度、失败终态、重试计数、主状态优先布局；删除旧打赏组件 |
| `aglaia/gui/colors.py` | 修改 | 删除打赏专用颜色，不影响错误提示颜色 |
| `aglaia/gui/import_paths.py` | 新增 | 公共图片/PDF分类及递归目录展开 |
| `aglaia/gui/sidebar/ActivityBar.py` | 修改 | 删除打赏组件和专用中部容器，保留导航/设置交互 |
| `aglaia/gui/sidebar/SidebarPanel.py` | 修改 | 删除打赏注册接口 |
| `aglaia/gui/sidebar/tabs/ExportTab.py` | 修改 | 仅保留文本格式及可用态 |
| `aglaia/gui/sidebar/tabs/ImportTab.py` | 修改 | 目录按钮、HEIC、队列去重、DPI |
| `aglaia/gui/sidebar/tabs/OcrTab.py` | 修改 | OCR开始/当前页/结束状态 |
| `aglaia/i18n/__init__.py` | 修改 | 简体中文支持、显示层元数据汉化函数 |
| `aglaia/i18n/aglaia_en_US.ts` | 修改 | 现有英文/法文词条/编译资源同步维护 |
| `aglaia/i18n/aglaia_fr_FR.ts` | 修改 | 现有英文/法文词条/编译资源同步维护 |
| `aglaia/i18n/aglaia_zh_CN.ts` | 新增 | 新增简体中文词条/编译资源 |
| `aglaia/i18n/qm/aglaia_en_US.qm` | 修改 | 现有英文/法文词条/编译资源同步维护 |
| `aglaia/i18n/qm/aglaia_fr_FR.qm` | 修改 | 现有英文/法文词条/编译资源同步维护 |
| `aglaia/i18n/qm/aglaia_zh_CN.qm` | 新增 | 新增简体中文词条/编译资源 |
| `aglaia/i18n/zh_metadata.py` | 新增 | 全部动态中文标签、说明和枚举映射 |
| `aglaia/processors/DPIfixer.py` | 修改 | 不无谓放大已有大图、上采样像素预算 |
| `aglaia/processors/PageDetector.py` | 修改 | 危险凸包斜切的矩形回退 |
| `aglaia/workers/ImportHelpers.py` | 修改 | 公共解码器、DPI强制、图片/PDF路径去重及统计 |
| `aglaia/workers/IntegratedProcessingChain.py` | 修改 | 步骤/失败事件、分支重试、软回收、新进程内存重试 |
| `aglaia/workers/OcrWorker.py` | 修改 | 正在OCR的页或页段信号 |
| `aglaia/workers/ProcessMonitor.py` | 修改 | 步骤开始/页面失败事件转发 |
| `aglaia/workers/cli.py` | 修改 | CLI图片后缀增加HEIC/HEIF |
| `aglaia/workers/headless.py` | 修改 | 无界面导入复用HEIC解码器 |
| `aglaia/workers/image_io.py` | 新增 | HEIC/Pillow方向纠正与RGB解码 |
| `aglaia/workers/md_export.py` | 修改 | Markdown导出覆盖统计 |
| `aglaia/workers/ocr/glm_ocr.py` | 修改 | GLM MLX revision与权重完整性清单 |
| `aglaia/workers/ocr/openai_compat.py` | 修改 | HTML转Markdown重复列表编号修正 |
| `aglaia/workers/text_only_archive.py` | 新增 | 严格全页文本/页索引归档、关闭后复核清理 |
| `aglaia/workers/vlm/backends.py` | 修改 | 冻结MLX服务改用内部入口 |
| `docs/export.md` | 修改 | 仅保留文本导出与删除规则文档 |
| `docs/imagebuffer.md` | 修改 | 200 DPI处理链文档 |
| `docs/pipeline.md` | 修改 | 200 DPI、自定义流程/草稿与合成说明文档 |
| `docs/theme.md` | 修改 | 删除打赏专用颜色文档，纠正错误色用途说明 |
| `localization_tests/test_dynamic_metadata_zh.py` | 新增 | 对应模块的新增或扩充回归测试；本轮实测范围见 test-results.json |
| `localization_tests/test_i18n_zh_catalog.py` | 新增 | 对应模块的新增或扩充回归测试；本轮实测范围见 test-results.json |
| `pyproject.toml` | 修改 | pillow-heif运行依赖 |
| `scripts/i18n_build_zh.py` | 新增 | 历史中文首稿生成/常用词覆写工具，非运行依赖 |
| `scripts/i18n_extract.sh` | 修改 | 把中文目录纳入词条提取 |
| `tests/gui/test_custom_pipelines.py` | 新增 | 对应模块的新增或扩充回归测试；本轮实测范围见 test-results.json |
| `tests/gui/test_export_destinations.py` | 修改 | 对应模块的新增或扩充回归测试；本轮实测范围见 test-results.json |
| `tests/gui/test_folder_import.py` | 新增 | 对应模块的新增或扩充回归测试；本轮实测范围见 test-results.json |
| `tests/gui/test_markdown_export_guard.py` | 新增 | 对应模块的新增或扩充回归测试；本轮实测范围见 test-results.json |
| `tests/gui/test_no_donation_ui.py` | 新增 | 对应模块的新增或扩充回归测试；本轮实测范围见 test-results.json |
| `tests/gui/test_progress_bar.py` | 修改 | 对应模块的新增或扩充回归测试；本轮实测范围见 test-results.json |
| `tests/gui/test_workflow_progress.py` | 新增 | 对应模块的新增或扩充回归测试；本轮实测范围见 test-results.json |
| `tests/processors/test_dpifixer_memory_guard.py` | 新增 | 对应模块的新增或扩充回归测试；本轮实测范围见 test-results.json |
| `tests/processors/test_hull_roi.py` | 修改 | 对应模块的新增或扩充回归测试；本轮实测范围见 test-results.json |
| `tests/storage/test_ocr_multi_engine.py` | 修改 | 对应模块的新增或扩充回归测试；本轮实测范围见 test-results.json |
| `tests/test_downloads.py` | 修改 | 对应模块的新增或扩充回归测试；本轮实测范围见 test-results.json |
| `tests/test_frozen_entrypoint.py` | 新增 | 对应模块的新增或扩充回归测试；本轮实测范围见 test-results.json |
| `tests/workers/test_chain_retry_failure.py` | 新增 | 对应模块的新增或扩充回归测试；本轮实测范围见 test-results.json |
| `tests/workers/test_heic_import.py` | 新增 | 对应模块的新增或扩充回归测试；本轮实测范围见 test-results.json |
| `tests/workers/test_openai_compat_ocr.py` | 修改 | 对应模块的新增或扩充回归测试；本轮实测范围见 test-results.json |
| `tests/workers/test_text_only_archive.py` | 新增 | 对应模块的新增或扩充回归测试；本轮实测范围见 test-results.json |
| `tests/workers/test_vlm.py` | 修改 | 对应模块的新增或扩充回归测试；本轮实测范围见 test-results.json |
| `tests/workers/test_worker_memory_policy.py` | 新增 | 对应模块的新增或扩充回归测试；本轮实测范围见 test-results.json |
| `tools/compare_ocr_models.py` | 新增 | 样本页OCR引擎比较与耗时工具 |
| `uv.lock` | 修改 | pillow-heif锁定及跨平台wheel记录 |
