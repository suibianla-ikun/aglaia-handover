import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const output = path.dirname(fileURLToPath(import.meta.url));
const repo = path.resolve(process.argv[2] || path.join(output, '../../../aglaia-zh-src'));
const expectedBase = '38429ba2b4b7476abc13c2db6009f102013c7ae9';
const sha = bytes => crypto.createHash('sha256').update(bytes).digest('hex');
function git(args, expected = [0]) {
  const result = spawnSync('git', args, { cwd: repo, maxBuffer: 64 * 1024 * 1024 });
  assert(expected.includes(result.status), `${args.join(' ')}: ${result.stderr}`);
  return result.stdout;
}
const split0 = value => value.toString('utf8').split('\0').filter(Boolean);
const base = git(['rev-parse', 'HEAD']).toString().trim();
assert.equal(base, expectedBase, 'The source baseline changed; review before exporting.');
assert.equal(git(['diff', '--cached', '--name-only']).length, 0, 'Do not use a changed index as baseline.');
const initialStatus = git(['status', '--porcelain=v1', '-z', '--untracked-files=all']);
const initialIndex = git(['ls-files', '--stage', '-z']);
const modified = split0(git(['diff', '--name-only', '-z', 'HEAD']));
const added = split0(git(['ls-files', '--others', '--exclude-standard', '-z']));
assert.equal(modified.length, 57);
assert.equal(added.length, 21);
const notes = {
  'Aglaia.spec': '打包翻译资源、Mac 中文 bundle、冻结 MLX 服务依赖',
  'README.md': '删除文档打赏邀请，保留上游许可说明',
  'aglaia/__main__.py': '冻结应用内部 MLX-VLM 服务入口',
  'aglaia/app.py': '默认导入 DPI、项目关闭后的文本归档清理',
  'aglaia/app_data/db.py': 'OCR 默认简体中文和英文；移除打赏配置与读取函数',
  'aglaia/app_data/downloads.py': 'Surya MLX 下载大小和必需权重清单',
  'aglaia/assets/SKILL.md': 'Aglaia 操作说明的 DPI/像素预算补充',
  'aglaia/gui/AboutDialog.py': '移除打赏链接及界面版权/许可证展示；源码声明保留',
  'aglaia/gui/MainWindow.py': '去重提示、阶段进度、失败恢复、OCR提醒、导出守卫、文本归档；移除打赏注册和跳转',
  'aglaia/gui/ModePicker.py': '模板汉化、固定新建入口、空流程、草稿保留',
  'aglaia/gui/PipelineEditorWidget.py': '元数据汉化、自定义命名保存、枚举原值、最终合成说明',
  'aglaia/gui/PipelineStepsOutline.py': '步骤和参数摘要汉化',
  'aglaia/gui/ScanItemWidget.py': '失败页警示/手动恢复入口',
  'aglaia/gui/SettingsTab.py': '双语言默认回退；删除打赏开关及其保存逻辑',
  'aglaia/gui/StartupWindow.py': '新建项目目录导入、HEIC筛选、200 DPI及范围；删除打赏入口及专用发光样式',
  'aglaia/gui/StatusBarWidget.py': '详细进度、失败终态、重试计数、主状态优先布局；删除旧打赏组件',
  'aglaia/gui/colors.py': '删除打赏专用颜色，不影响错误提示颜色',
  'aglaia/gui/sidebar/ActivityBar.py': '删除打赏组件和专用中部容器，保留导航/设置交互',
  'aglaia/gui/sidebar/SidebarPanel.py': '删除打赏注册接口',
  'aglaia/gui/import_paths.py': '公共图片/PDF分类及递归目录展开',
  'aglaia/gui/sidebar/tabs/ExportTab.py': '仅保留文本格式及可用态',
  'aglaia/gui/sidebar/tabs/ImportTab.py': '目录按钮、HEIC、队列去重、DPI',
  'aglaia/gui/sidebar/tabs/OcrTab.py': 'OCR开始/当前页/结束状态',
  'aglaia/i18n/__init__.py': '简体中文支持、显示层元数据汉化函数',
  'aglaia/i18n/zh_metadata.py': '全部动态中文标签、说明和枚举映射',
  'aglaia/processors/DPIfixer.py': '不无谓放大已有大图、上采样像素预算',
  'aglaia/processors/PageDetector.py': '危险凸包斜切的矩形回退',
  'aglaia/workers/ImportHelpers.py': '公共解码器、DPI强制、图片/PDF路径去重及统计',
  'aglaia/workers/IntegratedProcessingChain.py': '步骤/失败事件、分支重试、软回收、新进程内存重试',
  'aglaia/workers/OcrWorker.py': '正在OCR的页或页段信号',
  'aglaia/workers/ProcessMonitor.py': '步骤开始/页面失败事件转发',
  'aglaia/workers/cli.py': 'CLI图片后缀增加HEIC/HEIF',
  'aglaia/workers/headless.py': '无界面导入复用HEIC解码器',
  'aglaia/workers/image_io.py': 'HEIC/Pillow方向纠正与RGB解码',
  'aglaia/workers/md_export.py': 'Markdown导出覆盖统计',
  'aglaia/workers/text_only_archive.py': '严格全页文本/页索引归档、关闭后复核清理',
  'aglaia/workers/ocr/glm_ocr.py': 'GLM MLX revision与权重完整性清单',
  'aglaia/workers/ocr/openai_compat.py': 'HTML转Markdown重复列表编号修正',
  'aglaia/workers/vlm/backends.py': '冻结MLX服务改用内部入口',
  'docs/export.md': '仅保留文本导出与删除规则文档',
  'docs/imagebuffer.md': '200 DPI处理链文档',
  'docs/pipeline.md': '200 DPI、自定义流程/草稿与合成说明文档',
  'docs/theme.md': '删除打赏专用颜色文档，纠正错误色用途说明',
  'pyproject.toml': 'pillow-heif运行依赖',
  'scripts/i18n_extract.sh': '把中文目录纳入词条提取',
  'scripts/i18n_build_zh.py': '历史中文首稿生成/常用词覆写工具，非运行依赖',
  'tools/compare_ocr_models.py': '样本页OCR引擎比较与耗时工具',
  'uv.lock': 'pillow-heif锁定及跨平台wheel记录',
};
function purpose(file) {
  if (notes[file]) return notes[file];
  if (/^aglaia\/config\/pipelines\/.+\.yaml$/.test(file)) return '内置流程输出DPI 300/300改为200/200';
  if (/^aglaia\/i18n\/(qm\/)?aglaia_.+\.(ts|qm)$/.test(file)) return file.includes('zh_CN') ? '新增简体中文词条/编译资源' : '现有英文/法文词条/编译资源同步维护';
  if (/^(tests|localization_tests)\//.test(file)) return '对应模块的新增或扩充回归测试；本轮实测范围见 test-results.json';
  throw new Error(`Unclassified modification: ${file}`);
}
const all = [...modified, ...added].sort();
assert.equal(new Set(all).size, all.length);
const records = all.map(file => {
  assert(fs.lstatSync(path.join(repo, file)).isFile(), `Unsupported source file: ${file}`);
  const current = fs.readFileSync(path.join(repo, file));
  const isNew = added.includes(file);
  const prior = isNew ? null : git(['show', `HEAD:${file}`]);
  return { path: file, status: isNew ? 'new_untracked' : 'modified', purpose: purpose(file), bytes: current.length, sha256: sha(current), baseline_sha256: prior === null ? null : sha(prior) };
});
const trackedPatch = git(['diff', '--no-ext-diff', '--binary', '--full-index', 'HEAD']);
const patch = Buffer.concat([trackedPatch, ...added.map(file => git(['diff', '--no-index', '--binary', '--full-index', '--', '/dev/null', file], [1]))]);
fs.writeFileSync(path.join(output, 'aglaia-local-changes.patch'), patch);
const xmlParser = `import json, sys, string, re, xml.etree.ElementTree as ET
payload=json.loads(sys.stdin.read())
def parse(text):
 root=ET.fromstring(text)
 rows=[]
 for context in root.findall('context'):
  for message in context.findall('message'):
   trans=message.find('translation')
   rows.append({'context':context.findtext('name',''), 'source':message.findtext('source',''), 'comment':message.findtext('comment',''), 'translation':''.join(trans.itertext()) if trans is not None else '', 'type':trans.get('type','') if trans is not None else 'missing'})
 return root,rows
def tokens(text):
 try: fields=[f for _,f,_,_ in string.Formatter().parse(text) if f is not None]
 except ValueError: fields=[]
 return sorted(fields+re.findall(r'%(?:L?\\d+|n|[sdif])',text))
root,rows=parse(payload['zh'])
_,english=parse(payload['en'])
keys=lambda seq:{(r['context'],r['source'],r['comment']) for r in seq}
stats={'language':root.get('language'), 'contexts':len(root.findall('context')), 'messages':len(rows), 'unique_keys':len(keys(rows)), 'english_key_match':keys(rows)==keys(english), 'unfinished':sum(r['type']=='unfinished' for r in rows), 'empty':sum(not r['translation'].strip() for r in rows), 'cjk_messages':sum(bool(re.search('[\\u3400-\\u9fff]',r['translation'])) for r in rows), 'placeholder_mismatches':[{'context':r['context'],'source':r['source']} for r in rows if tokens(r['source'])!=tokens(r['translation'])]}
print(json.dumps({'stats':stats,'messages':rows},ensure_ascii=False))
`;
const python = path.join(repo, '.venv/bin/python');
const translationsResult = spawnSync(python, ['-c', xmlParser], {
  input: JSON.stringify({ zh: fs.readFileSync(path.join(repo, 'aglaia/i18n/aglaia_zh_CN.ts'), 'utf8'), en: fs.readFileSync(path.join(repo, 'aglaia/i18n/aglaia_en_US.ts'), 'utf8') }),
  maxBuffer: 16 * 1024 * 1024,
});
assert.equal(translationsResult.status, 0, translationsResult.stderr.toString());
const translations = JSON.parse(translationsResult.stdout);
const metadataResult = spawnSync(python, ['-c', 'import ast,json,sys; t=ast.parse(sys.stdin.read()); print(json.dumps({n.targets[0].id:ast.literal_eval(n.value) if n.targets[0].id!="OPTION_HELP" else [{"processor":k[0],"field":k[1],"text":v} for k,v in ast.literal_eval(n.value).items()] for n in t.body if isinstance(n,ast.Assign)},ensure_ascii=False))'], {
  input: fs.readFileSync(path.join(repo, 'aglaia/i18n/zh_metadata.py')), maxBuffer: 4 * 1024 * 1024,
});
assert.equal(metadataResult.status, 0, metadataResult.stderr.toString());
const metadata = JSON.parse(metadataResult.stdout);
const jsonWrite = (name, value) => fs.writeFileSync(path.join(output, name), `${JSON.stringify(value, null, 2)}\n`);
jsonWrite('zh-translations.json', translations);
jsonWrite('runtime-metadata.json', metadata);
const cell = text => String(text).replaceAll('\\', '\\\\').replaceAll('\t', '\\t').replaceAll('\r', '\\r').replaceAll('\n', '\\n');
fs.writeFileSync(path.join(output, 'zh-translations.tsv'), ['context\tsource\ttranslation\tcomment\ttype', ...translations.messages.map(r => [r.context, r.source, r.translation, r.comment, r.type].map(cell).join('\t'))].join('\n') + '\n');
fs.writeFileSync(path.join(output, 'LICENSE.txt'), fs.readFileSync(path.join(repo, 'LICENSE')));
const manifest = { schema_version: 1, inventory_date: '2026-10-11', upstream: 'https://github.com/yb85/aglaia', baseline_commit: base, scope: 'Current net source changes only; not a Windows acceptance or installed-bundle identity check.', counts: { modified: modified.length, new_untracked: added.length, total: records.length, test_files: records.filter(r => /^(tests|localization_tests)\//.test(r.path)).length }, patch: { name: 'aglaia-local-changes.patch', bytes: patch.length, sha256: sha(patch) }, translations: translations.stats, runtime_metadata_counts: Object.fromEntries(Object.entries(metadata).map(([k, v]) => [k, Array.isArray(v) ? v.length : Object.keys(v).length])), files: records };
jsonWrite('changes.json', manifest);
fs.writeFileSync(path.join(output, 'files.md'), `# 全部改动文件\n\n基线：\`${base}\`。${records.length} 个文件：${modified.length} 个修改，${added.length} 个新增，含 ${manifest.counts.test_files} 个测试文件。\n\n所有路径相对于 Aglaia 仓库根目录；新文件未跟踪状态也已包含在补丁中。完整 SHA-256 见 changes.json。\n\n| 文件 | 状态 | 用途 |\n| --- | --- | --- |\n${records.map(r => `| \`${r.path}\` | ${r.status === 'modified' ? '修改' : '新增'} | ${r.purpose} |`).join('\n')}\n`);
const patchHeaders = patch.toString().split('\n').filter(line => line.startsWith('diff --git '));
assert.equal(patchHeaders.length, records.length);
for (const file of all) assert(patchHeaders.includes(`diff --git a/${file} b/${file}`));
const baseCheck = spawnSync('git', ['apply', '--cached', '--check', path.join(output, 'aglaia-local-changes.patch')], { cwd: repo });
assert.equal(baseCheck.status, 0, baseCheck.stderr.toString());
const currentCheck = spawnSync('git', ['apply', '--reverse', '--check', path.join(output, 'aglaia-local-changes.patch')], { cwd: repo });
assert.equal(currentCheck.status, 0, currentCheck.stderr.toString());
for (const record of records) assert.equal(sha(fs.readFileSync(path.join(repo, record.path))), record.sha256);
assert.deepEqual(git(['status', '--porcelain=v1', '-z', '--untracked-files=all']), initialStatus);
assert.deepEqual(git(['ls-files', '--stage', '-z']), initialIndex);
const testResults = JSON.parse(fs.readFileSync(path.join(output, 'test-results.json'), 'utf8'));
const verification = { inventory_date: '2026-10-11', source_files: records.length, patch_file_coverage: true, index_baseline_apply_check_exit: baseCheck.status, current_tree_reverse_check_exit: currentCheck.status, source_hashes_unchanged_during_export: true, source_status_unchanged_during_export: true, source_index_entries_unchanged: true, translation_stats: translations.stats, task_test_results: testResults, product_tests_run_by_exporter: false, installed_app_run_or_replaced: false, windows_build_run: false, model_download_or_install: false, copied_book_inputs_credentials_config_or_models: false, notes: ['The exporter performs static document and patch validation only; task test results are recorded separately.', 'Donation and in-app ownership display source edits precede this export; unchanged checks cover the export operation, not the whole task.', 'No patch was applied and no Git commit or worktree was created.', 'Python in this exporter is a structured XML/AST parser over stdin, not an Aglaia launcher or source writer.'] };
jsonWrite('verification.json', verification);
console.log(JSON.stringify({ counts: manifest.counts, translations: translations.stats, runtime_metadata_counts: manifest.runtime_metadata_counts, patch_bytes: patch.length, validation: 'passed: exact file coverage, baseline/current dry checks, unchanged source hashes/status/index' }, null, 2));
